package com.employee.proyect.core.jobs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.proyect.core.jobs.model.JobsEntity;

public interface JobsRepository extends JpaRepository<JobsEntity, Number>{

}
