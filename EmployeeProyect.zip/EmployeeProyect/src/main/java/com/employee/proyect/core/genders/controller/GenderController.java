package com.employee.proyect.core.genders.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.employee.proyect.core.genders.model.GenderDto;
import com.employee.proyect.core.genders.model.GenderEntity;
import com.employee.proyect.core.genders.service.GenderService;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("api/v1/gender")
public class GenderController {
	
private final GenderService genderService;
	
	
	public GenderController(GenderService genderService) {
		this.genderService = genderService;
	}
	
	@GetMapping
	public Iterable<GenderDto> getGender(){
		return genderService.findAllGenders();
	}
			
	@GetMapping("/{id}")
	public GenderDto getGenderById(@PathVariable("id") Number id) {
		return genderService.findGenderById(id);
	}
	
	@PostMapping
	public GenderDto postGender(@Valid @RequestBody GenderDto genderDto) {
		System.out.println(genderDto.toString());
		return genderService.addGender(genderDto);
	}
	
	@PutMapping("/{id}")
	public void putGender(@PathVariable("id") Number id, @Valid @RequestBody GenderDto genderDto) {
		GenderDto genderIdDto = genderService.findGenderById(id);
				
		if(!id.equals(genderIdDto.getId())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No se encuentra el gender id solicitado."); 
		}
		genderService.updateGender(id, genderDto);
	}
	
	@DeleteMapping("/{id}")
	public void deleteGenderById(@PathVariable("id") Number id) {
		genderService.deleteGenderById(id);
	}

}
