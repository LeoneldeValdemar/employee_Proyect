package com.employee.proyect.core.employees.model;

import java.sql.Date;

public class EmployeesDto {

	private Number id;
	private Number genderId; 
	private Number jobId; 
	private String name; 
	private String lastName; 
	private Date birthDate;
	
	public Number getId() {
		return id;
	}
	public void setId(Number id) {
		this.id = id;
	}
	public Number getGenderId() {
		return genderId;
	}
	public void setGenderId(Number genderId) {
		this.genderId = genderId;
	}
	public Number getJobId() {
		return jobId;
	}
	public void setJobId(Number jobId) {
		this.jobId = jobId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	
	@Override
	public String toString() {
		return "CustomerDto [id=" + id + ", genderId=" 
				+ genderId + ", jobId=" + jobId 
				+ ", name=" + name + ", lastName=" 
				+ lastName + ", birthDate=" + birthDate + "]";
	}
	
}
