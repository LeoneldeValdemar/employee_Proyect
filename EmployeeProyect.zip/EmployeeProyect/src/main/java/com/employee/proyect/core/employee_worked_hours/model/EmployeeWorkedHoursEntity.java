package com.employee.proyect.core.employee_worked_hours.model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Entity
@Table(name="employeeWorkedHours")

public class EmployeeWorkedHoursEntity {
	
	/*@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="ID")
	@Column(nullable = false, updatable = false)*/
	@NotNull(message="El campo Id es requerido.")
	private Number id;
	
	@NotNull(message="El campo de Employee Id es requerido.")
	private Number employeeId; 
	
	@NotNull(message="El campo Worked Hours es requerido.")
	private Number workedHours; 
	
	@NotNull(message="La fecha de Worked Date es requerida.")
	private Date workedDate;

	public Number getId() {
		return id;
	}

	public void setId(Number id) {
		this.id = id;
	}

	public Number getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Number employeeId) {
		this.employeeId = employeeId;
	}

	public Number getWorkedHours() {
		return workedHours;
	}

	public void setWorkedHous(Number workedHours) {
		this.workedHours = workedHours;
	}

	public Date getWorkedDate() {
		return workedDate;
	}

	public void setWorkedDate(Date workedDate) {
		this.workedDate = workedDate;
	}

	@Override
	public String toString() {
		return "EmployeeWorkedHoursEntity [id=" + id + ", "
				+ "employeeId=" + employeeId + ", "
				+ "workedHours=" + workedHours + ", "
				+ "workedDate=" + workedDate + "]";
	}
	
}
