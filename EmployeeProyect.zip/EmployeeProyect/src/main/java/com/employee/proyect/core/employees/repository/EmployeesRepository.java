package com.employee.proyect.core.employees.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.employee.proyect.core.employees.model.EmployeesEntity;

public interface EmployeesRepository extends JpaRepository<EmployeesEntity, Number>{

}
