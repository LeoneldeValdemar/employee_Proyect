package com.employee.proyect.core.jobs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.employee.proyect.core.NotFoundException;
import com.employee.proyect.core.jobs.model.JobsDto;
import com.employee.proyect.core.jobs.model.JobsEntity;
import com.employee.proyect.core.jobs.repository.JobsRepository;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class JobsService {
	private final JobsRepository jobsRepository;
	private final ModelMapper jobsMapper;
	
	public JobsService(ModelMapper mapper, JobsRepository repository) {
		this.jobsMapper = mapper;
		this.jobsRepository = repository;
	}
	
	public List<JobsDto> findAllJobs(){
		List<JobsEntity> jobsEntityList = new ArrayList<JobsEntity>(jobsRepository.findAll());
		return jobsEntityList.stream().map(this::convertToDto).collect(Collectors.toList());
	}
		
	public JobsDto findJobsById(Number id) {
		return this.convertToDto(findOrThrow(id));
	}
	
	public void deleteJobsById(Number id) {
		jobsRepository.deleteById(id);
	}
	
	public JobsDto addJobs(JobsDto jobs) {
		System.out.println("Jobs Service, Adding Jobs Entity: " + jobs.toString());
		return convertToDto(jobsRepository.save(convertToEntity(jobs)));		
	}
	
	public void updateJobs(Number id, JobsDto jobsDto) {
		this.findOrThrow(id);
		jobsRepository.save(convertToEntity(jobsDto));
	}
	
	public JobsDto convertToDto(JobsEntity entity) {
		return this.jobsMapper.map(entity,  JobsDto.class);
	}
	
	public JobsEntity convertToEntity(JobsDto dto) {
		System.out.println("construyendo entity desde dto: "+dto);
		JobsEntity entity = jobsMapper.map(dto, JobsEntity.class);
		entity.toString();
		return entity;
	}
	
	private JobsEntity findOrThrow(final Number id) {
		return jobsRepository.findById(id)	
				         .orElseThrow(
				        		 () -> new NotFoundException("No se encontró el Jobs con el id " + id + ".")
				        		 );
	}

}
