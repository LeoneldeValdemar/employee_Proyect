package com.employee.proyect.core.jobs.model;

public class JobsDto {

	private Number id;
	private String name; 
	private Number salary;
	
	public Number getId() {
		return id;
	}
	public void setIdCliente(Number id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Number getSalary() {
		return salary;
	}
	public void setSalary(Number salary) {
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return "CustomerDto [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
}
