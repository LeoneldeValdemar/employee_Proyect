package com.employee.proyect.core.employees.model;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@Table(name="employees")

public class EmployeesEntity {
	
	@NotNull(message="El campo id es requerido.")
	private Number id;
	
	@NotNull(message="El campo gender id es requerido.")
	private Number genderId; 
	
	@NotNull(message="El campo job id es requerido.")
	private Number jobId;
	
	@NotNull(message="El campo name es requerido.")
	private String name; 
	
	@NotNull(message="El campo last name es requerido.")
	private String lastName; 
	
	@NotNull(message="El campo birth date es requerido.")
	private Date birthDate;

	public Number getId() {
		return id;
	}

	public void setId(Number id) {
		this.id = id;
	}

	public Number getGenderId() {
		return genderId;
	}

	public void setGenderId(Number genderId) {
		this.genderId = genderId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	@Override
	public String toString() {
		return "EmployeesEntity [id=" + id + ", genderId=" + genderId + ", jobId=" + jobId + ", name="
				+ name + ", lastName=" + lastName + ", birthDate=" + birthDate + "]";
	}
	
}
