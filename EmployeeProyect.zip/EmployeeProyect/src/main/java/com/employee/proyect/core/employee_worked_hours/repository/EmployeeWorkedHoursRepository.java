package com.employee.proyect.core.employee_worked_hours.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.employee.proyect.core.employee_worked_hours.model.EmployeeWorkedHoursEntity;

public interface EmployeeWorkedHoursRepository extends JpaRepository<EmployeeWorkedHoursEntity, Number>{

}
