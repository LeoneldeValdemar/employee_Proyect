package com.employee.proyect.core.employees.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.employee.proyect.core.NotFoundException;
import com.employee.proyect.core.employees.model.EmployeesDto;
import com.employee.proyect.core.employees.model.EmployeesEntity;
import com.employee.proyect.core.employees.repository.EmployeesRepository;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class EmployeesService {
	private final EmployeesRepository EmployeesRepository;
	private final ModelMapper EmployeesMapper;
	
	public EmployeesService(ModelMapper employeesMapper, EmployeesRepository employeesRepository) {
		this.EmployeesMapper = employeesMapper;
		this.EmployeesRepository = employeesRepository;
	}
	
	public List<EmployeesDto> findAllEmployees(){
		List<EmployeesEntity> employeesEntityList = new ArrayList<EmployeesEntity>(EmployeesRepository.findAll());
		return employeesEntityList.stream().map(this::convertToDto).collect(Collectors.toList());
	}
		
	public EmployeesDto findEmployeesById(Number id) {
		return this.convertToDto(findOrThrow(id));
	}
	
	public void deleteEmployeesById(Number id) {
		EmployeesRepository.deleteById(id);
	}
	
	public EmployeesDto addEmployees(EmployeesDto employees) {
		System.out.println("Employees Service, Adding Employees Entity: " + employees.toString());
		return convertToDto(EmployeesRepository.save(convertToEntity(employees)));		
	}
	
	public void updateEmployees(Number id, EmployeesDto employeesDto) {
		this.findOrThrow(id);
		EmployeesRepository.save(convertToEntity(employeesDto));
	}
	
	public EmployeesDto convertToDto(EmployeesEntity entity) {
		return this.EmployeesMapper.map(entity,  EmployeesDto.class);
	}
	
	public EmployeesEntity convertToEntity(EmployeesDto dto) {
		System.out.println("employees entity desde dto: "+dto);
		EmployeesEntity entity = EmployeesMapper.map(dto, EmployeesEntity.class);
		entity.toString();
		return entity;
	}
	
	private EmployeesEntity findOrThrow(final Number id) {
		return EmployeesRepository.findById(id)	
				         .orElseThrow(
				        		 () -> new NotFoundException("No se encontró el Employees con id " + id + ".")
				        		 );
	}

}
