package com.employee.proyect.core.employee_worked_hours.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.employee.proyect.core.employee_worked_hours.model.EmployeeWorkedHoursDto;
import com.employee.proyect.core.employee_worked_hours.model.EmployeeWorkedHoursEntity;
import com.employee.proyect.core.employee_worked_hours.service.EmployeeWorkedHoursService;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("api/v1/employeeWorkedHours")
public class EmployeeWorkedHoursController {
	
private final EmployeeWorkedHoursService employeeWorkedHoursService;
	
	
	public EmployeeWorkedHoursController(EmployeeWorkedHoursService service) {
		this.employeeWorkedHoursService = service;
	}
	
	@GetMapping
	public Iterable<EmployeeWorkedHoursDto> getCustomers(){
		return employeeWorkedHoursService.findAllEmployeeWorkedHours();
	}
			
	@GetMapping("/{id}")
	public EmployeeWorkedHoursDto getEmployeeWorkedHoursById(@PathVariable("id") Number id) {
		return employeeWorkedHoursService.findEmployeeWorkedHoursById(id);
	}
	
	@PostMapping
	public EmployeeWorkedHoursDto postCustomer(@Valid @RequestBody EmployeeWorkedHoursDto customerDto) {
		System.out.println(customerDto.toString());
		return employeeWorkedHoursService.addEmployeeWorkedHours(customerDto);
	}
	
	@PutMapping("/{id}")
	public void putEmployeeWorkedHours(@PathVariable("id") Number id, @Valid @RequestBody EmployeeWorkedHoursDto employeeWorkedHoursDto) {
		EmployeeWorkedHoursDto employeeWorkedHoursIdDto = employeeWorkedHoursService.findEmployeeWorkedHoursById(id);
				
		if(!id.equals(employeeWorkedHoursIdDto.getId())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No se encuentra el id del Employee solicitado."); 
		}
		employeeWorkedHoursService.updateEmployeeWorkedHours(id, employeeWorkedHoursDto);
	}
	
	@DeleteMapping("/{id}")
	public void deleteEmployeeWorkedHoursById(@PathVariable("id") Number id) {
		employeeWorkedHoursService.deleteEmployeeWorkedHoursById(id);
	}

}
