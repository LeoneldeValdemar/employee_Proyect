package com.employee.proyect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeProyectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeProyect.class, args);
	}

}
