package com.employee.proyect.core.genders.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.employee.proyect.core.NotFoundException;
import com.employee.proyect.core.genders.model.GenderDto;
import com.employee.proyect.core.genders.model.GenderEntity;
import com.employee.proyect.core.genders.repository.GenderRepository;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class GenderService {
	private final GenderRepository genderRepository;
	private final ModelMapper genderMapper;
	
	public GenderService(ModelMapper genderMapper, GenderRepository repository) {
		this.genderMapper = genderMapper;
		this.genderRepository = repository;
	}
	
	public List<GenderDto> findAllGenders(){
		List<GenderEntity> genderEntityList = new ArrayList<GenderEntity>(genderRepository.findAll());
		return genderEntityList.stream().map(this::convertToDto).collect(Collectors.toList());
	}
		
	public GenderDto findGenderById(Number id) {
		return this.convertToDto(findOrThrow(id));
	}
	
	public void deleteGenderById(Number id) {
		genderRepository.deleteById(id);
	}
	
	public GenderDto addGender(GenderDto gender) {
		System.out.println("Gender Service, Adding gender Entity: " + gender.toString());
		return convertToDto(genderRepository.save(convertToEntity(gender)));		
	}
	
	public void updateGender(Number id, GenderDto genderDto) {
		this.findOrThrow(id);
		genderRepository.save(convertToEntity(genderDto));
	}
	
	public GenderDto convertToDto(GenderEntity entity) {
		return this.genderMapper.map(entity,  GenderDto.class);
	}
	
	public GenderEntity convertToEntity(GenderDto dto) {
		System.out.println("gender entity desde dto: "+dto);
		GenderEntity entity = genderMapper.map(dto, GenderEntity.class);
		entity.toString();
		return entity;
	}
	
	private GenderEntity findOrThrow(final Number id) {
		return genderRepository.findById(id)	
				         .orElseThrow(
				        		 () -> new NotFoundException("No se encontró el gender con el id " + id + ".")
				        		 );
	}

}
