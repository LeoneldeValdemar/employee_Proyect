package com.employee.proyect.core.jobs.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.employee.proyect.core.jobs.model.JobsDto;
import com.employee.proyect.core.jobs.service.JobsService;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("api/v1/jobs")
public class JobsController {
	
private final JobsService jobsService;
	
	
	public JobsController(JobsService jobsService) {
		this.jobsService = jobsService;
	}
	
	@GetMapping
	public Iterable<JobsDto> getCustomers(){
		return jobsService.findAllJobs();
	}
			
	@GetMapping("/{id}")
	public JobsDto getJobsById(@PathVariable("id") Number id) {
		return jobsService.findJobsById(id);
	}
	
	@PostMapping
	public JobsDto postCustomer(@Valid @RequestBody JobsDto jobsDto) {
		System.out.println(jobsDto.toString());
		return jobsService.addJobs(jobsDto);
	}
	
	@PutMapping("/{id}")
	public void putJobs(@PathVariable("id") Number id, @Valid @RequestBody JobsDto jobsDto) {
		JobsDto jobsIdDto = jobsService.findJobsById(id);
				
		if(!id.equals(jobsIdDto.getId())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No se encuentra el jobs id solicitado."); 
		}
		jobsService.updateJobs(id, jobsDto);
	}
	
	@DeleteMapping("/{id}")
	public void deleteJobsById(@PathVariable("id") Number id) {
		jobsService.deleteJobsById(id);
	}

}
