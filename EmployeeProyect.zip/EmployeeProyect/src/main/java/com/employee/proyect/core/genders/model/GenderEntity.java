package com.employee.proyect.core.genders.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Entity
@Table(name="gender")

public class GenderEntity {
	
	@NotNull(message="El campo id es requerido.")
	private Number id;
	
	@NotNull(message="El campo name es requerido.")
	@Size(max=255)
	private String name;

	public Number getId() {
		return id;
	}

	public void setId(Number id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "CustomerEntity [id=" + id + ", name=" + name + "]";
	}
	
}
