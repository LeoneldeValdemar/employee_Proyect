package com.employee.proyect.core.employee_worked_hours.model;

import java.sql.Date;

import org.yaml.snakeyaml.events.Event.ID;

public class EmployeeWorkedHoursDto {

	private Number id;
	private Number employeeId; 
	private Number workedHours; 
	private Date workedDate; 

	
	public Number getId() {
		return id;
	}
	public void setId(Number id) {
		this.id = id;
	}
	public Number getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Number employeeId) {
		this.employeeId = employeeId;
	}
	public Number getWorkedHours() {
		return workedHours;
	}
	public void setWorkedHours(Number workedHours) {
		this.workedHours = workedHours;
	}
	public Date getWorkedDate() {
		return workedDate;
	}
	public void setWorkedDate(Date workedDate) {
		this.workedDate = workedDate;
	}

	@Override
	public String toString() {
		return "EmployeeWorkedHoursDto [id=" + id + ", "
				+ "employeeId=" + employeeId + ", "
				+ "workedHours=" + workedHours + ", "
				+ "workedDate=" + workedDate + "]";
	}
	
}
