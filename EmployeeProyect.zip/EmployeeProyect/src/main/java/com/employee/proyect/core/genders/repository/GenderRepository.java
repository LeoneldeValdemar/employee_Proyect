package com.employee.proyect.core.genders.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.proyect.core.genders.model.GenderEntity;

public interface GenderRepository extends JpaRepository<GenderEntity, Number>{

}
