package com.employee.proyect.core.employee_worked_hours.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.employee.proyect.core.NotFoundException;
import com.employee.proyect.core.employee_worked_hours.model.EmployeeWorkedHoursDto;
import com.employee.proyect.core.employee_worked_hours.model.EmployeeWorkedHoursEntity;
import com.employee.proyect.core.employee_worked_hours.repository.EmployeeWorkedHoursRepository;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class EmployeeWorkedHoursService {
	private final EmployeeWorkedHoursRepository employeeWorkedHoursRepository;
	private final ModelMapper employeeWorkedHoursMapper;
	
	public EmployeeWorkedHoursService(ModelMapper employeeWorkedHoursMapper, EmployeeWorkedHoursRepository employeeWorkedHoursRepository) {
		this.employeeWorkedHoursMapper = employeeWorkedHoursMapper;
		this.employeeWorkedHoursRepository = employeeWorkedHoursRepository;
	}
	
	public List<EmployeeWorkedHoursDto> findAllEmployeeWorkedHours(){
		List<EmployeeWorkedHoursEntity> EmployeeWorkedHoursEntityList = new ArrayList<EmployeeWorkedHoursEntity>(employeeWorkedHoursRepository.findAll());
		return EmployeeWorkedHoursEntityList.stream().map(this::convertToDto).collect(Collectors.toList());		
	}
	
	public EmployeeWorkedHoursDto findEmployeeWorkedHoursById(Number id) {
		return this.convertToDto(findOrThrow(id));
	}
	
	public void deleteEmployeeWorkedHoursById(Number id) {
		employeeWorkedHoursRepository.deleteById(id);
	}
	
	public EmployeeWorkedHoursDto addEmployeeWorkedHours(EmployeeWorkedHoursDto EmployeeWorkedHoursDto) {
		return convertToDto(employeeWorkedHoursRepository.save(convertToEntity(EmployeeWorkedHoursDto)));
	}
	
	public void updateEmployeeWorkedHours(Number id, EmployeeWorkedHoursDto EmployeeWorkedHoursDto) {
		findOrThrow(id);
		employeeWorkedHoursRepository.save(convertToEntity(EmployeeWorkedHoursDto));
	}
	
	public EmployeeWorkedHoursDto convertToDto(EmployeeWorkedHoursEntity EmployeeWorkedHoursEntity) {
		return this.employeeWorkedHoursMapper.map(EmployeeWorkedHoursEntity, EmployeeWorkedHoursDto.class);
	}
	
	public EmployeeWorkedHoursEntity convertToEntity(EmployeeWorkedHoursDto EmployeeWorkedHoursDto) {
		return this.employeeWorkedHoursMapper.map(EmployeeWorkedHoursDto, EmployeeWorkedHoursEntity.class);		
	}
	
	private EmployeeWorkedHoursEntity findOrThrow(Number id) {
		return employeeWorkedHoursRepository.findById(id)
				.orElseThrow(
		        		 () -> new NotFoundException("No se encontró a el Id del Employee " + id + ".")
		        		 );
	}
}
