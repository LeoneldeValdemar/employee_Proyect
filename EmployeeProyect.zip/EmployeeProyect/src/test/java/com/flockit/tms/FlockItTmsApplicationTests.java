package com.flockit.tms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlockItTmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
